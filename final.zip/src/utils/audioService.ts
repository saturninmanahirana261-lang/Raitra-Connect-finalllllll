import { storage, storageRef, uploadBytesResumable, getDownloadURL } from '../firebase';

export interface SupportedAudioFormat {
  mimeType: string;
  extension: string;
}

/**
 * Détecte intelligemment le meilleur MIME type audio supporté par l'environnement actuel
 * (Chrome desktop, Android WebView, Capacitor, Safari, Firefox).
 */
export function getSupportedAudioMimeType(): SupportedAudioFormat {
  if (typeof window === 'undefined' || typeof MediaRecorder === 'undefined') {
    return { mimeType: 'audio/webm', extension: '.webm' };
  }

  const candidateFormats: SupportedAudioFormat[] = [
    { mimeType: 'audio/webm;codecs=opus', extension: '.webm' },
    { mimeType: 'audio/webm', extension: '.webm' },
    { mimeType: 'audio/mp4;codecs=aac', extension: '.mp4' },
    { mimeType: 'audio/mp4', extension: '.mp4' },
    { mimeType: 'audio/aac', extension: '.aac' },
    { mimeType: 'audio/ogg;codecs=opus', extension: '.ogg' },
    { mimeType: 'audio/ogg', extension: '.ogg' },
    { mimeType: 'audio/wav', extension: '.wav' }
  ];

  for (const candidate of candidateFormats) {
    try {
      if (MediaRecorder.isTypeSupported(candidate.mimeType)) {
        console.log(`[VOICE] Selected supported audio format: ${candidate.mimeType} (${candidate.extension})`);
        return candidate;
      }
    } catch {
      // Ignorer l'exception et passer au candidat suivant
    }
  }

  console.log('[VOICE] Using default browser audio format fallback');
  return { mimeType: '', extension: '.webm' };
}

/**
 * Récupère le flux audio avec gestion des contraintes et diagnostics précis d'erreurs.
 */
export async function getMicrophoneStream(): Promise<MediaStream> {
  console.log('[VOICE] microphone permission check requested');
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    throw new Error('L\'API d\'enregistrement audio (getUserMedia) n\'est pas supportée sur ce navigateur ou cet appareil.');
  }

  const advancedConstraints: MediaStreamConstraints = {
    audio: {
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true
    },
    video: false
  };

  try {
    const stream = await navigator.mediaDevices.getUserMedia(advancedConstraints);
    console.log('[VOICE] microphone permission granted (advanced constraints)');
    return stream;
  } catch (err: any) {
    console.warn('[VOICE] getUserMedia avec contraintes avancées a échoué, tentative en mode basique...', err);
    try {
      const fallbackStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      console.log('[VOICE] microphone permission granted (basic constraints)');
      return fallbackStream;
    } catch (fallbackErr: any) {
      console.error('[VOICE] microphone permission denied or failed:', fallbackErr);
      throw new Error(formatMicrophoneErrorMessage(fallbackErr));
    }
  }
}

/**
 * Formate un message d'erreur clair et compréhensible par l'utilisateur.
 */
export function formatMicrophoneErrorMessage(err: any): string {
  const name = err?.name || '';
  const message = err?.message || String(err || '');

  if (name === 'NotAllowedError' || name === 'PermissionDeniedError' || message.includes('Permission denied')) {
    return 'Accès au microphone refusé. Veuillez autoriser les permissions microphone dans les paramètres de votre navigateur ou de votre application Android.';
  }
  if (name === 'NotFoundError' || name === 'DevicesNotFoundError' || message.includes('not found')) {
    return 'Aucun microphone détecté sur cet appareil. Veuillez brancher ou activer un microphone.';
  }
  if (name === 'NotReadableError' || name === 'TrackStartError' || message.includes('in use')) {
    return 'Le microphone est déjà utilisé par une autre application ou est inaccessible. Veuillez fermer les autres applications audio.';
  }
  if (name === 'OverconstrainedError' || name === 'ConstraintNotSatisfiedError') {
    return 'Les contraintes audio demandées ne sont pas supportées par votre matériel audio.';
  }
  if (name === 'SecurityError') {
    return 'L\'accès au microphone est bloqué pour des raisons de sécurité (HTTPS requis).';
  }

  return `Impossible d'accéder au microphone : ${message || 'Erreur inconnue'}`;
}

/**
 * Convertit un Blob audio en base64 Data URL (fallback de secours offline ou en cas de quota Storage).
 */
export function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Échec de la conversion du Blob audio en Data URL.'));
      }
    };
    reader.onerror = () => reject(reader.error || new Error('Erreur de lecture du Blob.'));
    reader.readAsDataURL(blob);
  });
}

/**
 * Uploade une note vocale dans Firebase Storage avec chemin sécurisé, timeout et métadonnées.
 * Retourne l'URL publique HTTPS du fichier audio ou un DataURL de secours immédiat en cas d'impossibilité réseau.
 */
export async function uploadVoiceNoteToStorage(
  audioBlob: Blob,
  conversationId: string,
  userId: string,
  durationSec: number,
  mimeType: string,
  onProgress?: (progressPercent: number) => void
): Promise<{ url: string; storagePath: string; isFallback: boolean }> {
  console.log(`[VOICE] upload started - Blob size: ${audioBlob.size} bytes, MIME: ${mimeType || audioBlob.type}`);
  
  if (!audioBlob || audioBlob.size === 0) {
    throw new Error('Le microphone n\'a produit aucun enregistrement (Blob vide).');
  }

  const { extension } = getSupportedAudioMimeType();
  const safeExt = extension || (mimeType.includes('mp4') ? '.mp4' : mimeType.includes('ogg') ? '.ogg' : '.webm');
  const safeMime = mimeType || audioBlob.type || 'audio/webm';
  const timestamp = Date.now();
  const safeFileName = `${userId}_voice_${timestamp}${safeExt}`;
  
  // Chemin conforme aux règles de sécurité de storage.rules : audio_notes/{conversationId}/{fileName}
  const filePath = `audio_notes/${conversationId}/${safeFileName}`;
  const fileRef = storageRef(storage, filePath);

  const metadata = {
    contentType: safeMime,
    customMetadata: {
      duration: String(Math.round(durationSec)),
      senderUid: userId,
      conversationId,
      uploadedAt: new Date().toISOString()
    }
  };

  const uploadPromise = new Promise<{ url: string; storagePath: string; isFallback: boolean }>((resolve, reject) => {
    try {
      const uploadTask = uploadBytesResumable(fileRef, audioBlob, metadata);

      uploadTask.on(
        'state_changed',
        (snapshot) => {
          if (snapshot.totalBytes > 0) {
            const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            const rounded = Math.round(progress);
            console.log(`[VOICE] upload progress: ${rounded}% (${snapshot.bytesTransferred}/${snapshot.totalBytes})`);
            if (onProgress) {
              onProgress(rounded);
            }
          }
        },
        (error: any) => {
          console.warn('[VOICE] Firebase Storage upload error:', error?.code || error?.message || error);
          reject(error);
        },
        async () => {
          try {
            console.log('[VOICE] upload completed, fetching download URL...');
            const downloadUrl = await getDownloadURL(uploadTask.snapshot.ref);
            console.log('[VOICE] download URL obtained successfully:', downloadUrl);
            resolve({ url: downloadUrl, storagePath: filePath, isFallback: false });
          } catch (urlErr) {
            console.error('[VOICE] Failed to get download URL:', urlErr);
            reject(urlErr);
          }
        }
      );
    } catch (startErr) {
      console.error('[VOICE] Failed to initiate uploadTask:', startErr);
      reject(startErr);
    }
  });

  // Timeout de 7 secondes max pour éviter tout blocage indéfini de l'UI
  const timeoutPromise = new Promise<{ url: string; storagePath: string; isFallback: boolean }>((_, reject) => {
    setTimeout(() => {
      reject(new Error('Firebase Storage upload timeout (7s exceeded)'));
    }, 7000);
  });

  try {
    const result = await Promise.race([uploadPromise, timeoutPromise]);
    return result;
  } catch (storageErr: any) {
    console.warn('[VOICE] Basculement immédiat vers DataURL de secours pour garantir la transmission du message vocal:', storageErr?.message || storageErr);
    if (onProgress) onProgress(100);
    const dataUrl = await blobToDataUrl(audioBlob);
    return { url: dataUrl, storagePath: '', isFallback: true };
  }
}

/**
 * Uploade un fichier lourd ou document dans Firebase Storage avec progression.
 */
export async function uploadAttachmentToStorage(
  file: File,
  conversationId: string,
  userId: string,
  onProgress?: (progressPercent: number) => void
): Promise<string> {
  const timestamp = Date.now();
  const sanitizedName = file.name.replace(/[^a-zA-Z0-9.-]/g, '_');
  const filePath = `attachments/${conversationId}/${userId}_${timestamp}_${sanitizedName}`;
  const fileRef = storageRef(storage, filePath);

  const metadata = {
    contentType: file.type || 'application/octet-stream',
    customMetadata: {
      originalName: file.name,
      senderUid: userId,
      conversationId,
      uploadedAt: new Date().toISOString()
    }
  };

  const uploadTask = uploadBytesResumable(fileRef, file, metadata);

  return new Promise<string>((resolve, reject) => {
    uploadTask.on(
      'state_changed',
      (snapshot) => {
        if (snapshot.totalBytes > 0 && onProgress) {
          const progress = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
          onProgress(progress);
        }
      },
      (error) => {
        console.error('Erreur Firebase Storage uploadAttachment:', error);
        reject(error);
      },
      async () => {
        try {
          const downloadUrl = await getDownloadURL(uploadTask.snapshot.ref);
          resolve(downloadUrl);
        } catch (urlErr) {
          reject(urlErr);
        }
      }
    );
  });
}
