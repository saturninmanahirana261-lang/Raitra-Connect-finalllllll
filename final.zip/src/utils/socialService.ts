import {
  db,
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  startAfter,
  onSnapshot,
  increment,
  storage,
  storageRef,
  uploadBytesResumable,
  getDownloadURL
} from '../firebase';
import type {
  SocialPost,
  SocialPostMedia,
  SocialReactionType,
  SocialPostReaction,
  SocialComment,
  SocialStory,
  SocialPage,
  SocialPageFollower,
  SocialNotification,
  SocialVisibility
} from '../types';

// ==========================================
// 1. COMPRESSION ET TÉLÉVERSEMENT DE MÉDIAS
// ==========================================

export async function compressImage(file: File, maxWidth = 1920, maxHeight = 1920, quality = 0.82): Promise<Blob> {
  return new Promise((resolve, reject) => {
    // Si c'est un GIF ou autre format spécial, on ne compresse pas
    if (file.type === 'image/gif') {
      resolve(file);
      return;
    }

    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        let { width, height } = img;
        if (width > maxWidth || height > maxHeight) {
          if (width > height) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(file);
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        canvas.toBlob(
          (blob) => {
            if (blob) {
              resolve(blob);
            } else {
              resolve(file);
            }
          },
          'image/jpeg',
          quality
        );
      };
      img.onerror = () => resolve(file);
    };
    reader.onerror = () => resolve(file);
  });
}

export async function uploadSocialMedia(
  file: File,
  userId: string,
  folder: 'posts' | 'stories' | 'pages',
  onProgress?: (progress: number) => void
): Promise<string> {
  let uploadBlob: Blob = file;
  let ext = file.name.substring(file.name.lastIndexOf('.')) || '.jpg';

  if (file.type.startsWith('image/')) {
    uploadBlob = await compressImage(file);
    ext = '.jpg';
  }

  const timestamp = Date.now();
  const randomStr = Math.random().toString(36).substring(2, 8);
  const path = `social_${folder}/${userId}/${timestamp}_${randomStr}${ext}`;
  const fileRef = storageRef(storage, path);

  const uploadTask = uploadBytesResumable(fileRef, uploadBlob, {
    contentType: file.type.startsWith('image/') ? 'image/jpeg' : file.type
  });

  return new Promise((resolve, reject) => {
    uploadTask.on(
      'state_changed',
      (snapshot) => {
        if (snapshot.totalBytes > 0 && onProgress) {
          const progress = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
          onProgress(progress);
        }
      },
      (error) => reject(error),
      async () => {
        const downloadUrl = await getDownloadURL(uploadTask.snapshot.ref);
        resolve(downloadUrl);
      }
    );
  });
}

// ==========================================
// 2. GESTION DES PUBLICATIONS (POSTS)
// ==========================================

export async function createSocialPost(params: {
  authorUid: string;
  authorName: string;
  authorEmail?: string;
  authorPhotoURL?: string;
  content: string;
  media?: SocialPostMedia[];
  visibility: SocialVisibility;
  pageId?: string;
  pageName?: string;
  pageAvatar?: string;
  sharedPostId?: string;
  sharedPost?: SocialPost['sharedPost'];
}): Promise<string> {
  const postRef = doc(collection(db, 'social_posts'));
  const postId = postRef.id;

  const newPost: SocialPost = {
    id: postId,
    authorUid: params.authorUid,
    authorName: params.authorName,
    authorEmail: params.authorEmail || '',
    authorPhotoURL: params.authorPhotoURL || '',
    content: params.content.trim(),
    media: params.media || [],
    visibility: params.visibility,
    pageId: params.pageId,
    pageName: params.pageName,
    pageAvatar: params.pageAvatar,
    reactionsCount: 0,
    reactionsSummary: {
      like: 0,
      love: 0,
      haha: 0,
      wow: 0,
      sad: 0,
      angry: 0
    },
    commentsCount: 0,
    sharesCount: 0,
    sharedPostId: params.sharedPostId,
    sharedPost: params.sharedPost,
    createdAt: Date.now()
  };

  await setDoc(postRef, newPost);

  // Si c'est un repartage, incrémenter le compteur de partages du post original
  if (params.sharedPostId) {
    try {
      const origRef = doc(db, 'social_posts', params.sharedPostId);
      await updateDoc(origRef, {
        sharesCount: increment(1)
      });
    } catch (e) {
      console.warn('Impossible d\'incrémenter le compteur de partage:', e);
    }
  }

  return postId;
}

export async function updateSocialPost(
  postId: string,
  content: string,
  visibility: SocialVisibility
): Promise<void> {
  const postRef = doc(db, 'social_posts', postId);
  await updateDoc(postRef, {
    content: content.trim(),
    visibility,
    isEdited: true,
    updatedAt: Date.now()
  });
}

export async function deleteSocialPost(postId: string): Promise<void> {
  const postRef = doc(db, 'social_posts', postId);
  await deleteDoc(postRef);
}

// ==========================================
// 3. RÉACTIONS AUX PUBLICATIONS
// ==========================================

export async function togglePostReaction(
  postId: string,
  user: { uid: string; displayName: string; photoURL?: string },
  newReaction: SocialReactionType
): Promise<{ activeReaction: SocialReactionType | null }> {
  const reactionId = `${postId}_${user.uid}`;
  const reactionRef = doc(db, 'social_post_reactions', reactionId);
  const postRef = doc(db, 'social_posts', postId);

  const snap = await getDoc(reactionRef);
  const existingData = snap.exists() ? (snap.data() as SocialPostReaction) : null;

  if (existingData) {
    if (existingData.reaction === newReaction) {
      // Retirer la réaction
      await deleteDoc(reactionRef);
      await updateDoc(postRef, {
        reactionsCount: increment(-1),
        [`reactionsSummary.${newReaction}`]: increment(-1)
      });
      return { activeReaction: null };
    } else {
      // Changer de réaction (ex: passer de like à love)
      const oldReaction = existingData.reaction;
      await updateDoc(reactionRef, {
        reaction: newReaction,
        createdAt: Date.now()
      });
      await updateDoc(postRef, {
        [`reactionsSummary.${oldReaction}`]: increment(-1),
        [`reactionsSummary.${newReaction}`]: increment(1)
      });
      return { activeReaction: newReaction };
    }
  } else {
    // Ajouter nouvelle réaction
    const newDoc: SocialPostReaction = {
      id: reactionId,
      postId,
      uid: user.uid,
      userName: user.displayName,
      userPhotoURL: user.photoURL || '',
      reaction: newReaction,
      createdAt: Date.now()
    };
    await setDoc(reactionRef, newDoc);
    await updateDoc(postRef, {
      reactionsCount: increment(1),
      [`reactionsSummary.${newReaction}`]: increment(1)
    });

    // Envoyer une notification à l'auteur du post
    try {
      const postSnap = await getDoc(postRef);
      if (postSnap.exists()) {
        const postData = postSnap.data() as SocialPost;
        if (postData.authorUid !== user.uid) {
          await createSocialNotification({
            recipientUid: postData.authorUid,
            senderUid: user.uid,
            senderName: user.displayName,
            senderPhotoURL: user.photoURL,
            type: 'reaction',
            targetId: postId,
            message: `a réagi à votre publication.`
          });
        }
      }
    } catch (e) {
      console.warn('Erreur notification réaction:', e);
    }

    return { activeReaction: newReaction };
  }
}

export async function getUserReactionForPost(postId: string, uid: string): Promise<SocialReactionType | null> {
  try {
    const reactionId = `${postId}_${uid}`;
    const snap = await getDoc(doc(db, 'social_post_reactions', reactionId));
    if (snap.exists()) {
      return snap.data().reaction as SocialReactionType;
    }
  } catch {
    // Ignorer si indisponible
  }
  return null;
}

// ==========================================
// 4. COMMENTAIRES AUX PUBLICATIONS
// ==========================================

export async function addSocialComment(params: {
  postId: string;
  parentCommentId?: string;
  authorUid: string;
  authorName: string;
  authorPhotoURL?: string;
  content: string;
}): Promise<SocialComment> {
  const commentRef = doc(collection(db, 'social_comments'));
  const commentId = commentRef.id;

  const newComment: SocialComment = {
    id: commentId,
    postId: params.postId,
    parentCommentId: params.parentCommentId,
    authorUid: params.authorUid,
    authorName: params.authorName,
    authorPhotoURL: params.authorPhotoURL || '',
    content: params.content.trim(),
    reactionsCount: 0,
    createdAt: Date.now()
  };

  await setDoc(commentRef, newComment);

  // Incrémenter le compteur de commentaires sur le post
  const postRef = doc(db, 'social_posts', params.postId);
  await updateDoc(postRef, {
    commentsCount: increment(1)
  });

  // Notification à l'auteur du post
  try {
    const postSnap = await getDoc(postRef);
    if (postSnap.exists()) {
      const postData = postSnap.data() as SocialPost;
      if (postData.authorUid !== params.authorUid) {
        await createSocialNotification({
          recipientUid: postData.authorUid,
          senderUid: params.authorUid,
          senderName: params.authorName,
          senderPhotoURL: params.authorPhotoURL,
          type: params.parentCommentId ? 'reply' : 'comment',
          targetId: params.postId,
          message: params.parentCommentId ? 'a répondu à un commentaire.' : 'a commenté votre publication.'
        });
      }
    }
  } catch (e) {
    console.warn('Erreur notification commentaire:', e);
  }

  return newComment;
}

export async function deleteSocialComment(postId: string, commentId: string): Promise<void> {
  const commentRef = doc(db, 'social_comments', commentId);
  await deleteDoc(commentRef);

  const postRef = doc(db, 'social_posts', postId);
  await updateDoc(postRef, {
    commentsCount: increment(-1)
  });
}

// ==========================================
// 5. STORIES 24 HEURES
// ==========================================

export async function createSocialStory(params: {
  authorUid: string;
  authorName: string;
  authorPhotoURL?: string;
  mediaUrl: string;
  mediaType: 'image' | 'video' | 'text';
  textCaption?: string;
  bgColor?: string;
  visibility: SocialVisibility;
}): Promise<string> {
  const storyRef = doc(collection(db, 'social_stories'));
  const storyId = storyRef.id;
  const now = Date.now();
  const expiresAt = now + 24 * 60 * 60 * 1000; // 24h

  const newStory: SocialStory = {
    id: storyId,
    authorUid: params.authorUid,
    authorName: params.authorName,
    authorPhotoURL: params.authorPhotoURL || '',
    mediaUrl: params.mediaUrl,
    mediaType: params.mediaType,
    textCaption: params.textCaption,
    bgColor: params.bgColor,
    visibility: params.visibility,
    viewers: [params.authorUid],
    viewersCount: 1,
    createdAt: now,
    expiresAt
  };

  await setDoc(storyRef, newStory);
  return storyId;
}

export async function markStoryAsViewed(storyId: string, viewerUid: string): Promise<void> {
  try {
    const storyRef = doc(db, 'social_stories', storyId);
    const snap = await getDoc(storyRef);
    if (snap.exists()) {
      const data = snap.data() as SocialStory;
      if (!data.viewers.includes(viewerUid)) {
        await updateDoc(storyRef, {
          viewers: [...data.viewers, viewerUid],
          viewersCount: increment(1)
        });
      }
    }
  } catch (e) {
    console.warn('Erreur markStoryAsViewed:', e);
  }
}

export async function deleteSocialStory(storyId: string): Promise<void> {
  const storyRef = doc(db, 'social_stories', storyId);
  await deleteDoc(storyRef);
}

// ==========================================
// 6. PAGES RAITRA CONNECT
// ==========================================

export async function createSocialPage(params: {
  name: string;
  category: string;
  description: string;
  avatarUrl?: string;
  coverUrl?: string;
  website?: string;
  location?: string;
  ownerUid: string;
}): Promise<string> {
  const pageRef = doc(collection(db, 'social_pages'));
  const pageId = pageRef.id;

  const newPage: SocialPage = {
    id: pageId,
    name: params.name.trim(),
    category: params.category,
    description: params.description.trim(),
    avatarUrl: params.avatarUrl || '',
    coverUrl: params.coverUrl || '',
    website: params.website?.trim(),
    location: params.location?.trim(),
    ownerUid: params.ownerUid,
    admins: [params.ownerUid],
    followersCount: 1,
    createdAt: Date.now()
  };

  await setDoc(pageRef, newPage);

  // Le créateur suit automatiquement sa propre page
  const followRef = doc(db, 'social_page_followers', `${pageId}_${params.ownerUid}`);
  await setDoc(followRef, {
    id: `${pageId}_${params.ownerUid}`,
    pageId,
    uid: params.ownerUid,
    createdAt: Date.now()
  });

  return pageId;
}

export async function toggleFollowPage(
  pageId: string,
  user: { uid: string; displayName: string; photoURL?: string }
): Promise<boolean> {
  const followId = `${pageId}_${user.uid}`;
  const followRef = doc(db, 'social_page_followers', followId);
  const pageRef = doc(db, 'social_pages', pageId);

  const snap = await getDoc(followRef);
  if (snap.exists()) {
    // Ne plus suivre
    await deleteDoc(followRef);
    await updateDoc(pageRef, {
      followersCount: increment(-1)
    });
    return false;
  } else {
    // Suivre
    const newFollow: SocialPageFollower = {
      id: followId,
      pageId,
      uid: user.uid,
      userName: user.displayName,
      userPhotoURL: user.photoURL || '',
      createdAt: Date.now()
    };
    await setDoc(followRef, newFollow);
    await updateDoc(pageRef, {
      followersCount: increment(1)
    });
    return true;
  }
}

export async function isFollowingPage(pageId: string, uid: string): Promise<boolean> {
  try {
    const followId = `${pageId}_${uid}`;
    const snap = await getDoc(doc(db, 'social_page_followers', followId));
    return snap.exists();
  } catch {
    return false;
  }
}

// ==========================================
// 7. NOTIFICATIONS SOCIALES
// ==========================================

export async function createSocialNotification(params: {
  recipientUid: string;
  senderUid: string;
  senderName: string;
  senderPhotoURL?: string;
  type: SocialNotification['type'];
  targetId: string;
  message: string;
}): Promise<void> {
  if (params.recipientUid === params.senderUid) return;

  const notifRef = doc(collection(db, 'social_notifications'));
  const newNotif: SocialNotification = {
    id: notifRef.id,
    recipientUid: params.recipientUid,
    senderUid: params.senderUid,
    senderName: params.senderName,
    senderPhotoURL: params.senderPhotoURL || '',
    type: params.type,
    targetId: params.targetId,
    message: params.message,
    isRead: false,
    createdAt: Date.now()
  };

  await setDoc(notifRef, newNotif);
}

export async function markNotificationAsRead(notifId: string): Promise<void> {
  const notifRef = doc(db, 'social_notifications', notifId);
  await updateDoc(notifRef, { isRead: true });
}

export async function markAllNotificationsAsRead(uid: string): Promise<void> {
  const q = query(
    collection(db, 'social_notifications'),
    where('recipientUid', '==', uid),
    where('isRead', '==', false)
  );
  const snap = await getDocs(q);
  const promises = snap.docs.map((d) => updateDoc(d.ref, { isRead: true }));
  await Promise.all(promises);
}
